// DinnerEvent.java
public class DinnerEvent extends Event {
    // Additional fields for DinnerEvent
    private int entreeChoice;
    private int sideDish1Choice;
    private int sideDish2Choice;
    private int dessertChoice;

    // Final arrays containing the menu options for each category
    public static final String[] ENTREES = {"Chicken", "Beef", "Fish"};
    public static final String[] SIDE_DISHES = {"Mashed Potatoes", "Steamed Vegetables", "Rice Pilaf"};
    public static final String[] DESSERTS = {"Cake", "Ice Cream", "Fruit Salad"};

    // Constructor that takes the event number, number of guests, and the menu choices
    public DinnerEvent(int eventNumber, int numberOfGuests, int entreeChoice, int sideDish1Choice, int sideDish2Choice, int dessertChoice) {
        super();  // Pass eventNumber and numberOfGuests to the Event constructor
        this.entreeChoice = entreeChoice;
        this.sideDish1Choice = sideDish1Choice;
        this.sideDish2Choice = sideDish2Choice;
        this.dessertChoice = dessertChoice;
    }

    // Method to return the menu choices as a string
    public String getMenu() {
        return "Entrée: " + ENTREES[entreeChoice] + "\n" +
                "Side Dish 1: " + SIDE_DISHES[sideDish1Choice] + "\n" +
                "Side Dish 2: " + SIDE_DISHES[sideDish2Choice] + "\n" +
                "Dessert: " + DESSERTS[dessertChoice];
    }

    // Override the toString method to include menu details
    @Override
    public String toString() {
        return super.toString() + "\n" + getMenu();
    }
}
