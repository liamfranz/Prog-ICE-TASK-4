// DinnerEventDemo.java
import java.util.Scanner;

public class DinnerEventDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        DinnerEvent[] events = new DinnerEvent[4];  // Array to store 4 DinnerEvent objects

        // Collect user input for each DinnerEvent
        for (int i = 0; i < events.length; i++) {
            System.out.println("Enter details for DinnerEvent " + (i + 1));

            System.out.print("Event Number: ");
            int eventNumber = scanner.nextInt();

            System.out.print("Number of Guests: ");
            int numberOfGuests = scanner.nextInt();

            System.out.println("Menu Choices:");
            System.out.println("1. Entrées: Chicken, Beef, Fish");
            System.out.print("Choose Entrée (0 = Chicken, 1 = Beef, 2 = Fish): ");
            int entreeChoice = scanner.nextInt();

            System.out.println("2. Side Dishes: Mashed Potatoes, Steamed Vegetables, Rice Pilaf");
            System.out.print("Choose Side Dish 1 (0 = Mashed Potatoes, 1 = Steamed Vegetables, 2 = Rice Pilaf): ");
            int sideDish1Choice = scanner.nextInt();

            System.out.print("Choose Side Dish 2 (0 = Mashed Potatoes, 1 = Steamed Vegetables, 2 = Rice Pilaf): ");
            int sideDish2Choice = scanner.nextInt();

            System.out.println("3. Desserts: Cake, Ice Cream, Fruit Salad");
            System.out.print("Choose Dessert (0 = Cake, 1 = Ice Cream, 2 = Fruit Salad): ");
            int dessertChoice = scanner.nextInt();

            // Create a new DinnerEvent object and store it in the array
            events[i] = new DinnerEvent(eventNumber, numberOfGuests, entreeChoice, sideDish1Choice, sideDish2Choice, dessertChoice);
            System.out.println(); // Print a blank line for separation
        }

        // Menu for sorting options
        while (true) {
            System.out.println("Choose a sorting option:");
            System.out.println("1. Sort by Event Number");
            System.out.println("2. Sort by Number of Guests");
            System.out.println("3. Sort by Event Type (ascending)");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    // Sort by Event Number
                    sortByEventNumber(events);
                    break;
                case 2:
                    // Sort by Number of Guests
                    sortByNumberOfGuests(events);
                    break;
                case 3:
                    // Sort by Event Type (this assumes event type can be determined, but we're skipping it here)
                    System.out.println("Sorting by event type is not implemented.");
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }

            // Print the sorted list of events
            printEvents(events);
        }
    }

    // Method to print all events
    private static void printEvents(DinnerEvent[] events) {
        for (DinnerEvent event : events) {
            System.out.println(event);  // Calls the overridden toString() method
            System.out.println("----------------------------");
        }
    }

    // Sort events by event number
    private static void sortByEventNumber(DinnerEvent[] events) {
        for (int i = 0; i < events.length - 1; i++) {
            for (int j = i + 1; j < events.length; j++) {
                if (events[i].getEventNumber() > events[j].getEventNumber()) {
                    DinnerEvent temp = events[i];
                    events[i] = events[j];
                    events[j] = temp;
                }
            }
        }
    }

    // Sort events by number of guests
    private static void sortByNumberOfGuests(DinnerEvent[] events) {
        for (int i = 0; i < events.length - 1; i++) {
            for (int j = i + 1; j < events.length; j++) {
                if (events[i].getNumberOfGuests() > events[j].getNumberOfGuests()) {
                    DinnerEvent temp = events[i];
                    events[i] = events[j];
                    events[j] = temp;
                }
            }
        }
    }
}
