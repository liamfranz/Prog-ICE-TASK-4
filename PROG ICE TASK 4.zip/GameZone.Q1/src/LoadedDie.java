// LoadedDie.java
import java.util.ArrayList;

public class LoadedDie extends Die {

    // Constructor calls the superclass constructor.
    public LoadedDie() {
        super();
    }

    // Override roll to avoid rolling a 1.
    @Override
    public void roll() {
        value = (int) (Math.random() * 5) + 2; // Generates a number between 2 and 6.
    }

    // Static method to simulate multiple rolls and return an ArrayList of LoadedDie objects.
    public static ArrayList<LoadedDie> rollMultiple(int count) {
        ArrayList<LoadedDie> diceList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            diceList.add(new LoadedDie()); // Create and roll each LoadedDie
        }
        return diceList;
    }
}
