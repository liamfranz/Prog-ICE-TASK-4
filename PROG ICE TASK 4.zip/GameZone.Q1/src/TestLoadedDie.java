// TestLoadedDie.java
import java.util.ArrayList;

public class TestLoadedDie {
    public static void main(String[] args) {
        // Number of rolls for testing
        int numberOfRolls = 1000;

        // Roll two regular Die objects against each other 1,000 times
        ArrayList<Die> dieList1 = Die.rollMultiple(numberOfRolls);
        ArrayList<Die> dieList2 = Die.rollMultiple(numberOfRolls);

        // Roll a Die object against a LoadedDie object 1,000 times
        ArrayList<Die> normalDieList = Die.rollMultiple(numberOfRolls);
        ArrayList<LoadedDie> loadedDieList = LoadedDie.rollMultiple(numberOfRolls);

        int dieWins = 0;
        int loadedDieWins = 0;
        int dieVsLoadedDieWins = 0;

        // Compare regular Die objects against each other
        for (int i = 0; i < numberOfRolls; i++) {
            if (dieList1.get(i).getValue() > dieList2.get(i).getValue()) {
                dieWins++;
            }
        }

        // Compare Die object against LoadedDie object
        for (int i = 0; i < numberOfRolls; i++) {
            if (normalDieList.get(i).getValue() > loadedDieList.get(i).getValue()) {
                dieVsLoadedDieWins++;
            }
        }

        // Display results
        System.out.println("Die vs Die: Number of times die1 wins: " + dieWins);
        System.out.println("Die vs LoadedDie: Number of times Die wins: " + dieVsLoadedDieWins);
    }
}
