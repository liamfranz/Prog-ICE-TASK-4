// Die.java
import java.util.ArrayList;

public class Die {
    protected int value; // The value of the die, protected so subclasses can access it.

    // Constructor initializes the value by rolling the die.
    public Die() {
        roll();
    }

    // Rolls the die and generates a random value between 1 and 6.
    public void roll() {
        value = (int) (Math.random() * 6) + 1; // Generates a number between 1 and 6.
    }

    // Getter for the value of the die.
    public int getValue() {
        return value;
    }

    // Static method to simulate multiple rolls and return an ArrayList of Die objects.
    public static ArrayList<Die> rollMultiple(int count) {
        ArrayList<Die> diceList = new ArrayList<>();
        for (int i = 0; i < count; i++) {
            diceList.add(new Die()); // Create and roll each die
        }
        return diceList;
    }
}
