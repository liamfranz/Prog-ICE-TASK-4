public class TeeShirt {
    private String orderNumber;
    private String size;
    private String color;
    private double price;

    public TeeShirt(String orderNumber, String size, String color) {
        this.orderNumber = orderNumber;
        setSize(size); // setSize will determine the price
        this.color = color;
    }

    // Getter for orderNumber
    public String getOrderNumber() {
        return orderNumber;
    }

    // Setter for orderNumber
    public void setOrderNumber(String orderNumber) {
        this.orderNumber = orderNumber;
    }

    // Getter for size
    public String getSize() {
        return size;
    }

    // Setter for size (updates price based on size)
    public void setSize(String size) {
        this.size = size;
        if (size.equals("XXL") || size.equals("XXXL")) {
            this.price = 22.99;
        } else {
            this.price = 19.99;
        }
    }

    // Getter for color
    public String getColor() {
        return color;
    }

    // Setter for color
    public void setColor(String color) {
        this.color = color;
    }

    // Getter for price
    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "TeeShirt [Order Number: " + orderNumber + ", Size: " + size +
                ", Color: " + color + ", Price: $" + price + "]";
    }
}
