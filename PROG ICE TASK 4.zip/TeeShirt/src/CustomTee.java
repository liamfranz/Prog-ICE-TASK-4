public class CustomTee extends TeeShirt {
    private String slogan;

    public CustomTee(String orderNumber, String size, String color, String slogan) {
        super(orderNumber, size, color); // Call the parent constructor
        this.slogan = slogan;
    }

    // Getter for slogan
    public String getSlogan() {
        return slogan;
    }

    // Setter for slogan
    public void setSlogan(String slogan) {
        this.slogan = slogan;
    }

    @Override
    public String toString() {
        return "CustomTee [Order Number: " + getOrderNumber() + ", Size: " + getSize() +
                ", Color: " + getColor() + ", Price: $" + getPrice() + ", Slogan: " + slogan + "]";
    }
}
