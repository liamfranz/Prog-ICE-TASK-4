import java.util.Scanner;

public class DemoTees {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create first TeeShirt
        System.out.print("Enter order number for TeeShirt 1: ");
        String orderNumber1 = scanner.nextLine();
        System.out.print("Enter size for TeeShirt 1 (e.g., S, M, L, XL, XXL, XXXL): ");
        String size1 = scanner.nextLine();
        System.out.print("Enter color for TeeShirt 1: ");
        String color1 = scanner.nextLine();

        TeeShirt teeShirt1 = new TeeShirt(orderNumber1, size1, color1);
        System.out.println("Created TeeShirt: " + teeShirt1);

        // Create second TeeShirt
        System.out.print("\nEnter order number for TeeShirt 2: ");
        String orderNumber2 = scanner.nextLine();
        System.out.print("Enter size for TeeShirt 2 (e.g., S, M, L, XL, XXL, XXXL): ");
        String size2 = scanner.nextLine();
        System.out.print("Enter color for TeeShirt 2: ");
        String color2 = scanner.nextLine();

        TeeShirt teeShirt2 = new TeeShirt(orderNumber2, size2, color2);
        System.out.println("Created TeeShirt: " + teeShirt2);

        // Create first CustomTee
        System.out.print("\nEnter order number for CustomTee 1: ");
        String orderNumberCustom1 = scanner.nextLine();
        System.out.print("Enter size for CustomTee 1 (e.g., S, M, L, XL, XXL, XXXL): ");
        String customSize1 = scanner.nextLine();
        System.out.print("Enter color for CustomTee 1: ");
        String customColor1 = scanner.nextLine();
        System.out.print("Enter slogan for CustomTee 1: ");
        String slogan1 = scanner.nextLine();

        CustomTee customTee1 = new CustomTee(orderNumberCustom1, customSize1, customColor1, slogan1);
        System.out.println("Created CustomTee: " + customTee1);

        // Create second CustomTee
        System.out.print("\nEnter order number for CustomTee 2: ");
        String orderNumberCustom2 = scanner.nextLine();
        System.out.print("Enter size for CustomTee 2 (e.g., S, M, L, XL, XXL, XXXL): ");
        String customSize2 = scanner.nextLine();
        System.out.print("Enter color for CustomTee 2: ");
        String customColor2 = scanner.nextLine();
        System.out.print("Enter slogan for CustomTee 2: ");
        String slogan2 = scanner.nextLine();

        CustomTee customTee2 = new CustomTee(orderNumberCustom2, customSize2, customColor2, slogan2);
        System.out.println("Created CustomTee: " + customTee2);

        scanner.close();
    }
}
