// Poker.java
public class Poker extends CardGame {

    // Constructor initializes the number of cards dealt to a player in Poker (5 cards)
    public Poker() {
        super();
        this.cardsDealt = 5;
    }

    // Implement the displayDescription method
    @Override
    public void displayDescription() {
        System.out.println("Poker: A popular card game where players are dealt 5 cards each. The goal is to have the best hand.");
    }

    // Implement the deal method for Poker
    @Override
    public void deal() {
        System.out.println("Dealing " + cardsDealt + " cards for Poker...");

        // Deal 5 cards by accessing the ArrayList
        for (int i = 0; i < cardsDealt; i++) {
            Card card = deck.get(i);
            System.out.println("Card " + (i + 1) + ": " + card);
        }
    }
}

