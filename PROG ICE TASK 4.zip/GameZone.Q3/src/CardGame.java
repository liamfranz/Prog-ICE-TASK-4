// CardGame.java
import java.util.ArrayList;

public abstract class CardGame {
    protected ArrayList<Card> deck;    // ArrayList to hold the deck of cards
    protected int cardsDealt;          // Number of cards dealt to a player in a game

    // Constructor initializes the deck of 52 cards
    public CardGame() {
        deck = new ArrayList<>();
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};

        // Initialize the deck with all the cards
        for (String suit : suits) {
            for (String value : values) {
                deck.add(new Card(suit, value));
            }
        }
    }

    // A simple deterministic shuffle by rotating the deck
    public void shuffle() {
        // Rotate the deck a fixed number of times (e.g., 5)
        for (int i = 0; i < 5; i++) {
            rotateDeck();
        }
    }

    // Rotate the deck by one position
    private void rotateDeck() {
        // Move the first card to the last position
        Card firstCard = deck.get(0);
        deck.remove(0);
        deck.add(firstCard);
    }

    // Abstract method to display a description of the game
    public abstract void displayDescription();

    // Abstract method to deal cards to a player
    public abstract void deal();
}

