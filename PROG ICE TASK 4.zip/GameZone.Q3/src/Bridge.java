// Bridge.java
public class Bridge extends CardGame {

    // Constructor initializes the number of cards dealt to a player in Bridge (13 cards)
    public Bridge() {
        super();
        this.cardsDealt = 13;
    }

    // Implement the displayDescription method
    @Override
    public void displayDescription() {
        System.out.println("Bridge: A trick-taking game where each player is dealt 13 cards. The goal is to win tricks.");
    }

    // Implement the deal method for Bridge
    @Override
    public void deal() {
        System.out.println("Dealing " + cardsDealt + " cards for Bridge...");

        // Deal 13 cards by accessing the ArrayList
        for (int i = 0; i < cardsDealt; i++) {
            Card card = deck.get(i);
            System.out.println("Card " + (i + 1) + ": " + card);
        }
    }
}

