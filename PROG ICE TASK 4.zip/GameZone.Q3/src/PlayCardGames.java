// PlayCardGames.java
public class PlayCardGames {
    public static void main(String[] args) {
        // Instantiate Poker and Bridge objects
        CardGame pokerGame = new Poker();
        CardGame bridgeGame = new Bridge();

        // Shuffle the decks before dealing
        pokerGame.shuffle();
        bridgeGame.shuffle();

        // Display descriptions and deal cards for Poker
        System.out.println("\n=== Poker Game ===");
        pokerGame.displayDescription();
        pokerGame.deal();

        // Display descriptions and deal cards for Bridge
        System.out.println("\n=== Bridge Game ===");
        bridgeGame.displayDescription();
        bridgeGame.deal();
    }
}

