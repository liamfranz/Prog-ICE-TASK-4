import java.util.Scanner;

public class DemoHorses {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for Horse
        System.out.print("Enter horse name: ");
        String horseName = scanner.nextLine();
        System.out.print("Enter horse color: ");
        String horseColor = scanner.nextLine();
        System.out.print("Enter horse birth year: ");
        int horseBirthYear = scanner.nextInt();
        scanner.nextLine(); // consume the newline

        Horse horse = new Horse(horseName, horseColor, horseBirthYear);
        System.out.println("Created Horse: " + horse);

        // Input for RaceHorse
        System.out.print("Enter race horse name: ");
        String raceHorseName = scanner.nextLine();
        System.out.print("Enter race horse color: ");
        String raceHorseColor = scanner.nextLine();
        System.out.print("Enter race horse birth year: ");
        int raceHorseBirthYear = scanner.nextInt();
        System.out.print("Enter number of races: ");
        int numberOfRaces = scanner.nextInt();

        RaceHorse raceHorse = new RaceHorse(raceHorseName, raceHorseColor, raceHorseBirthYear, numberOfRaces);
        System.out.println("Created RaceHorse: " + raceHorse);

        scanner.close();
    }
}

