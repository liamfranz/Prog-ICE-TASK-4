public class HighSchoolBaseballGame extends BaseballGame {
    protected final int INNINGS = 7;

    public HighSchoolBaseballGame(String team1Name, String team2Name) {
        super(team1Name, team2Name);
        scores = new int[2][INNINGS];
        initializeScores();
    }
}

