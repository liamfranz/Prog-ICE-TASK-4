import java.util.Scanner;

public class DemoBaseballGame {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select the type of baseball game:");
        System.out.println("1. High School Baseball Game");
        System.out.println("2. Little League Baseball Game");
        int choice = scanner.nextInt();
        scanner.nextLine(); // Consume the newline

        System.out.print("Enter name for Team 1: ");
        String team1 = scanner.nextLine();
        System.out.print("Enter name for Team 2: ");
        String team2 = scanner.nextLine();

        BaseballGame game;
        if (choice == 1) {
            game = new HighSchoolBaseballGame(team1, team2);
        } else {
            game = new LittleLeagueBaseballGame(team1, team2);
        }

        // Input scores for each inning
        for (int inning = 1; inning <= game.INNINGS; inning++) {
            System.out.print("Enter score for " + game.getTeam1Name() + " in inning " + inning + ": ");
            int score1 = scanner.nextInt();
            game.setScore(1, inning, score1);

            System.out.print("Enter score for " + game.getTeam2Name() + " in inning " + inning + ": ");
            int score2 = scanner.nextInt();
            game.setScore(2, inning, score2);

            // Display running scores
            System.out.println("After inning " + inning + ":");
            System.out.println(game.getTeam1Name() + " Score: " + score1);
            System.out.println(game.getTeam2Name() + " Score: " + score2);
        }

        // Determine winner
        int totalScore1 = 0;
        int totalScore2 = 0;
        for (int i = 0; i < game.INNINGS; i++) {
            totalScore1 += game.getScore(1, i + 1);
            totalScore2 += game.getScore(2, i + 1);
        }

        System.out.println("Final Score:");
        System.out.println(game.getTeam1Name() + ": " + totalScore1);
        System.out.println(game.getTeam2Name() + ": " + totalScore2);

        if (totalScore1 > totalScore2) {
            System.out.println(game.getTeam1Name() + " wins!");
        } else if (totalScore2 > totalScore1) {
            System.out.println(game.getTeam2Name() + " wins!");
        } else {
            System.out.println("It's a tie!");
        }

        scanner.close();
    }
}
