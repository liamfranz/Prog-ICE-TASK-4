public class BaseballGame {
    protected String team1Name;
    protected String team2Name;
    protected int[][] scores;
    protected final int INNINGS = 9;


    public BaseballGame(String team1Name, String team2Name) {
        this.team1Name = team1Name;
        this.team2Name = team2Name;
        scores = new int[2][INNINGS];
        initializeScores();
    }


    public void initializeScores() {
        for (int i = 0; i < 2; i++) {
            for (int j = 0; j < INNINGS; j++) {
                scores[i][j] = 0; 
            }
        }
    }

    // Set methods
    public void setTeam1Name(String name) {
        this.team1Name = name;
    }

    public void setTeam2Name(String name) {
        this.team2Name = name;
    }

    public void setScore(int team, int inning, int score) {
        if (team < 1 || team > 2 || inning < 1 || inning > INNINGS) {
            throw new IllegalArgumentException("Invalid team or inning number.");
        }
        scores[team - 1][inning - 1] = score; // team 1 -> index 0, team 2 -> index 1
    }

    // Get methods
    public String getTeam1Name() {
        return team1Name;
    }

    public String getTeam2Name() {
        return team2Name;
    }

    public int getScore(int team, int inning) {
        if (team < 1 || team > 2 || inning < 1 || inning > INNINGS) {
            throw new IllegalArgumentException("Invalid team or inning number.");
        }
        return scores[team - 1][inning - 1];
    }

    public int[] getScores(int team) {
        if (team < 1 || team > 2) {
            throw new IllegalArgumentException("Invalid team number.");
        }
        return scores[team - 1]; // Return scores for the specified team
    }
}
