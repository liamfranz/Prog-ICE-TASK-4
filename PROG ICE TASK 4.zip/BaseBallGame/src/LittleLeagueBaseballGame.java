public class LittleLeagueBaseballGame extends BaseballGame {
    protected final int INNINGS = 6; // Override to represent 6 innings for little league games

    // Constructor
    public LittleLeagueBaseballGame(String team1Name, String team2Name) {
        super(team1Name, team2Name);
        scores = new int[2][INNINGS]; // Update scores array for 6 innings
        initializeScores();
    }
}
