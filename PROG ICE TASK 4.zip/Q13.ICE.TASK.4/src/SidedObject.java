public interface SidedObject {
    String displaySides();
}

