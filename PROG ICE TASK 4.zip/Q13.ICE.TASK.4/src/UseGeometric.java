import java.util.Scanner;

public class UseGeometric {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        GeometricFigure[] figures = new GeometricFigure[5];

        for (int i = 0; i < figures.length; i++) {
            System.out.print("Enter type (Square or Triangle): ");
            String type = scanner.nextLine();

            if (type.equalsIgnoreCase("Square")) {
                System.out.print("Enter side length: ");
                double sideLength = scanner.nextDouble();
                figures[i] = new Square(sideLength);
            } else if (type.equalsIgnoreCase("Triangle")) {
                System.out.print("Enter height: ");
                double height = scanner.nextDouble();
                System.out.print("Enter base: ");
                double base = scanner.nextDouble();
                figures[i] = new Triangle(height, base);
            } else {
                System.out.println("Invalid type. Try again.");
                i--; // Decrement i to repeat the iteration for invalid input
            }
            scanner.nextLine(); // Consume newline
        }

        System.out.println("\nGeometric Figures:");
        for (GeometricFigure figure : figures) {
            System.out.println("Type: " + figure.getFigureType());
            System.out.println("Height: " + figure.getHeight());
            System.out.println("Width: " + figure.getWidth());
            System.out.println("Area: " + figure.calculateArea());
            System.out.println(figure.displaySides());
            System.out.println();
        }

        scanner.close();
    }
}
