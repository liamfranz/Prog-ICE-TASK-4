public class Triangle extends GeometricFigure {
    private double area;

    public Triangle(double height, double base) {
        super(height, base, "Triangle");
        this.area = calculateArea();
    }

    @Override
    public double calculateArea() {
        return 0.5 * height * width;
    }

    @Override
    public String displaySides() {
        return "A triangle has 3 sides.";
    }

    public double getArea() {
        return area;
    }
}
