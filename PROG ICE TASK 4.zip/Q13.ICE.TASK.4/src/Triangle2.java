public class Triangle2 extends GeometricFigure2 {
    private double area;

    public Triangle2(double height, double base) {
        super(height, base, "Triangle");
        this.area = calculateArea();
    }

    @Override
    public double calculateArea() {
        return 0.5 * height * width;
    }

    @Override
    public String displaySides() {
        return "A triangle has 3 sides.";
    }

    public double getArea() {
        return area;
    }
}

