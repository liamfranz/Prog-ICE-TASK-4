public class Square2 extends GeometricFigure2 {
    private double area;

    public Square2(double sideLength) {
        super(sideLength, sideLength, "Square");
        this.area = calculateArea();
    }

    @Override
    public double calculateArea() {
        return height * width; // Since height and width are the same for a square
    }

    @Override
    public String displaySides() {
        return "A square has 4 sides.";
    }

    public double getArea() {
        return area;
    }
}
