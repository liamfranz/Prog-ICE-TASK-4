public class IgneousRock extends Rock {
    public IgneousRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        // Assigning a description specific to Igneous Rocks
        this.description = "Igneous rock formed from cooled lava or magma.";
    }
}
