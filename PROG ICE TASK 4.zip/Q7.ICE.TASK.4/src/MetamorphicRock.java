public class MetamorphicRock extends Rock {
    public MetamorphicRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        // Assigning a description specific to Metamorphic Rocks
        this.description = "Metamorphic rock formed under pressure and heat.";
    }
}

