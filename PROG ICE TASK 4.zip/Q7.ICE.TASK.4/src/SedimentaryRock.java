public class SedimentaryRock extends Rock {
    public SedimentaryRock(int sampleNumber, double weight) {
        super(sampleNumber, weight);
        // Assigning a description specific to Sedimentary Rocks
        this.description = "Sedimentary rock formed from the accumulation of sediment.";
    }
}
