import java.util.Scanner;

public class DemoRocks {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the type of rock collected (U, I, S, M): ");
        String rockType = scanner.nextLine().trim().toUpperCase();

        Rock rock;
        if (rockType.equals("I")) {
            System.out.print("Enter sample number: ");
            int sampleNumber = scanner.nextInt();
            System.out.print("Enter weight in grams: ");
            double weight = scanner.nextDouble();
            rock = new IgneousRock(sampleNumber, weight);
        } else if (rockType.equals("S")) {
            System.out.print("Enter sample number: ");
            int sampleNumber = scanner.nextInt();
            System.out.print("Enter weight in grams: ");
            double weight = scanner.nextDouble();
            rock = new SedimentaryRock(sampleNumber, weight);
        } else if (rockType.equals("M")) {
            System.out.print("Enter sample number: ");
            int sampleNumber = scanner.nextInt();
            System.out.print("Enter weight in grams: ");
            double weight = scanner.nextDouble();
            rock = new MetamorphicRock(sampleNumber, weight);
        } else {
            rock = new Rock(0, 0);
        }

        displayRockDetails(rock);
        scanner.close();
    }

    public static void displayRockDetails(Rock rock) {
        System.out.println("Sample Number: " + rock.getSampleNumber());
        System.out.println("Description: " + rock.getDescription());
        System.out.println("Weight: " + rock.getWeight() + " grams");
    }
}

