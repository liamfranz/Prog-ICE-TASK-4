import java.util.Scanner;

public class UseDivision {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Division division = null;

        System.out.print("Enter 'I' for International Division or 'D' for Domestic Division: ");
        String choice = scanner.nextLine().trim().toUpperCase();

        if (choice.equals("I")) {
            System.out.print("Enter division name: ");
            String divisionName = scanner.nextLine();
            System.out.print("Enter account number: ");
            String accountNumber = scanner.nextLine();
            System.out.print("Enter country: ");
            String country = scanner.nextLine();
            System.out.print("Enter language spoken: ");
            String language = scanner.nextLine();
            division = new InternationalDivision(divisionName, accountNumber, country, language);
        } else if (choice.equals("D")) {
            System.out.print("Enter division name: ");
            String divisionName = scanner.nextLine();
            System.out.print("Enter account number: ");
            String accountNumber = scanner.nextLine();
            System.out.print("Enter state: ");
            String state = scanner.nextLine();
            division = new DomesticDivision(divisionName, accountNumber, state);
        } else {
            System.out.println("Invalid choice. No division created.");
        }

        if (division != null) {
            division.display();
        }

        scanner.close();
    }
}

