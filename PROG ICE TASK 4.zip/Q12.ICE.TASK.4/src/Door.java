public class Door implements Turner {
    @Override
    public void turn() {
        System.out.println("Opening the door.");
    }
}

