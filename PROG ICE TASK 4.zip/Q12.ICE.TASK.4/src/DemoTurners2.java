import java.util.Scanner;

public class DemoTurners2 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a type of turner (Leaf, Page, Pancake, Door, Wheel): ");
        String input = scanner.nextLine();

        Turner turner = null;

        switch (input.toLowerCase()) {
            case "leaf":
                turner = new Leaf();
                break;
            case "page":
                turner = new Page();
                break;
            case "pancake":
                turner = new Pancake();
                break;
            case "door":
                turner = new Door();
                break;
            case "wheel":
                turner = new Wheel();
                break;
            default:
                System.out.println("Unknown turner type.");
                break;
        }

        if (turner != null) {
            turner.turn();
        }

        scanner.close();
    }
}

