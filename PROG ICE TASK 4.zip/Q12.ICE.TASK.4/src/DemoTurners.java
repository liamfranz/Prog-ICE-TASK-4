import java.util.Scanner;

public class DemoTurners {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a type of turner (Leaf, Page, Pancake): ");
        String input = scanner.nextLine();

        Turner turner = null;

        switch (input.toLowerCase()) {
            case "leaf":
                turner = new Leaf();
                break;
            case "page":
                turner = new Page();
                break;
            case "pancake":
                turner = new Pancake();
                break;
            default:
                System.out.println("Unknown turner type.");
                break;
        }

        if (turner != null) {
            turner.turn();
        }

        scanner.close();
    }
}
