public class Wheel implements Turner {
    @Override
    public void turn() {
        System.out.println("Spinning the wheel.");
    }
}

