public class Pancake implements Turner {
    @Override
    public void turn() {
        System.out.println("Flipping.");
    }
}
