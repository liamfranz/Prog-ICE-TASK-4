public class Limerick extends Poem {
    private static final int LINES = 5;

    public Limerick(String title) {
        super(title, LINES);
    }

    @Override
    public String toString() {
        return "Limerick [Title: " + getTitle() + ", Number of Lines: " + getNumberOfLines() + "]";
    }
}

