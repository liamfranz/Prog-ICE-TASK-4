public class Poem {
    private String title;
    private int numberOfLines;

    public Poem(String title, int numberOfLines) {
        this.title = title;
        this.numberOfLines = numberOfLines;
    }

    // Getter for title
    public String getTitle() {
        return title;
    }

    // Getter for numberOfLines
    public int getNumberOfLines() {
        return numberOfLines;
    }

    @Override
    public String toString() {
        return "Poem [Title: " + title + ", Number of Lines: " + numberOfLines + "]";
    }
}
