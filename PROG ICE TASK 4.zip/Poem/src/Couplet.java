public class Couplet extends Poem {
    private static final int LINES = 2;

    public Couplet(String title) {
        super(title, LINES);
    }

    @Override
    public String toString() {
        return "Couplet [Title: " + getTitle() + ", Number of Lines: " + getNumberOfLines() + "]";
    }
}
