import java.util.Scanner;

public class DemoPoems {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int choice;

        // Prompt for valid poem type
        do {
            System.out.println("Select the type of poem to create:");
            System.out.println("1. Poem");
            System.out.println("2. Couplet");
            System.out.println("3. Limerick");
            System.out.println("4. Haiku");
            System.out.print("Enter your choice (1-4): ");
            choice = scanner.nextInt();
        } while (choice < 1 || choice > 4);

        scanner.nextLine(); // consume the newline

        System.out.print("Enter the title of the poem: ");
        String title = scanner.nextLine();

        Poem poem = null;

        // Create the appropriate poem object
        switch (choice) {
            case 1:
                System.out.print("Enter the number of lines: ");
                int numberOfLines = scanner.nextInt();
                poem = new Poem(title, numberOfLines);
                break;
            case 2:
                poem = new Couplet(title);
                break;
            case 3:
                poem = new Limerick(title);
                break;
            case 4:
                poem = new Haiku(title);
                break;
        }

        // Display the poem details
        System.out.println("Created: " + poem);

        scanner.close();
    }
}

