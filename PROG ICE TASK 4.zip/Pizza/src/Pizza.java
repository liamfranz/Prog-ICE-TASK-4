public class Pizza {
    private String[] toppings;
    private double price;
    private String description;

    public Pizza(String[] toppings, int numberOfToppings) {
        this.toppings = new String[numberOfToppings];
        System.arraycopy(toppings, 0, this.toppings, 0, numberOfToppings);

        this.description = String.join(", ", this.toppings);
        this.price = 14 + (numberOfToppings * 2);
    }

    @Override
    public String toString() {
        return "Pizza with toppings: " + description + ", Price: $" + price;
    }
}
