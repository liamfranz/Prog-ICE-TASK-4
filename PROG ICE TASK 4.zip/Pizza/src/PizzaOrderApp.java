import java.util.ArrayList;
import java.util.Scanner;

public class PizzaOrderApp {
    private static final String QUIT = "QUIT";

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<String> toppingsList = new ArrayList<>();

        System.out.println("Enter pizza toppings (type QUIT to stop):");

        while (toppingsList.size() < 10) {
            String topping = scanner.nextLine();
            if (topping.equalsIgnoreCase(QUIT)) {
                break;
            }
            toppingsList.add(topping);
        }

        String[] toppingsArray = toppingsList.toArray(new String[0]);

        System.out.print("Is this pizza for delivery? (yes/no): ");
        String deliveryChoice = scanner.nextLine().trim().toLowerCase();

        if (deliveryChoice.equals("yes")) {
            System.out.print("Enter delivery address: ");
            String deliveryAddress = scanner.nextLine();
            DeliveryPizza deliveryPizza = new DeliveryPizza(toppingsArray, deliveryAddress, toppingsArray.length);
            System.out.println(deliveryPizza);
        } else {
            Pizza pizza = new Pizza(toppingsArray, toppingsArray.length);
            System.out.println(pizza);
        }

        scanner.close();
    }
}
