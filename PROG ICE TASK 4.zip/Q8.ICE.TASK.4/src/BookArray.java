import java.util.Scanner;

public class BookArray {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Book[] books = new Book[10];

        for (int i = 0; i < books.length; i++) {
            String type;
            do {
                System.out.print("Enter the type of book (F for Fiction, N for NonFiction): ");
                type = scanner.nextLine().trim().toUpperCase();
            } while (!type.equals("F") && !type.equals("N"));

            System.out.print("Enter the title of the book: ");
            String title = scanner.nextLine();

            if (type.equals("F")) {
                books[i] = new Fiction(title);
            } else {
                books[i] = new NonFiction(title);
            }
        }

        System.out.println("\nBook Details:");
        for (Book book : books) {
            System.out.println("Title: " + book.getTitle() + ", Price: $" + book.getPrice());
        }

        scanner.close();
    }
}
