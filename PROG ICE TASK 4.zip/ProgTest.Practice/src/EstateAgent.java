public class EstateAgent implements IEstateAgent {
    private String name;
    private double[] sales;

    public EstateAgent(String name, double[] sales) {
        this.name = name;
        this.sales = sales;
    }

    // Calculate total sales
    @Override
    public double EstateAgentSales(double[] propertySales) {
        double total = 0;
        for (double sale : propertySales) {
            total += sale;
        }
        return total;
    }

    // Calculate commission (2%)
    @Override
    public double EstateAgentCommission(double propertySales) {
        return propertySales * 0.02;
    }

    // Compare total sales and return the index of the top-selling agent
    @Override
    public int TopEstateAgent(double[] totalSales) {
        if (totalSales[0] > totalSales[1]) {
            return 0; // Joe Bloggs
        } else {
            return 1; // Jane Doe
        }
    }

    public String getName() {
        return name;
    }

    public double[] getSales() {
        return sales;
    }
}

