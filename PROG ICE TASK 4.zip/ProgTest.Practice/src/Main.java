public class Main {
    public static void main(String[] args) {
        // Define sales data for two estate agents
        double[] joeSales = {800000, 1500000, 2000000}; // Joe Bloggs sales for Jan, Feb, Mar
        double[] janeSales = {700000, 1200000, 1600000}; // Jane Doe sales for Jan, Feb, Mar

        // Create EstateAgent objects
        EstateAgent joe = new EstateAgent("Joe Bloggs", joeSales);
        EstateAgent jane = new EstateAgent("Jane Doe", janeSales);

        // Calculate total sales for Joe and Jane
        double joeTotalSales = joe.EstateAgentSales(joeSales);
        double janeTotalSales = jane.EstateAgentSales(janeSales);

        // Calculate commission for Joe and Jane (2%)
        double joeCommission = joe.EstateAgentCommission(joeTotalSales);
        double janeCommission = jane.EstateAgentCommission(janeTotalSales);

        // Print out total sales and commissions
        System.out.println(joe.getName() + " - Total Sales: R " + joeTotalSales + " | Commission: R " + joeCommission);
        System.out.println(jane.getName() + " - Total Sales: R " + janeTotalSales + " | Commission: R " + janeCommission);

        // Use the TopEstateAgent method to determine the top performer
        EstateAgent[] agents = {joe, jane};
        double[] totalSales = {joeTotalSales, janeTotalSales};

        int topAgentIndex = joe.TopEstateAgent(totalSales);

        // Display the top-selling estate agent
        System.out.println("\nTop-selling Estate Agent: " + agents[topAgentIndex].getName());
    }
}
