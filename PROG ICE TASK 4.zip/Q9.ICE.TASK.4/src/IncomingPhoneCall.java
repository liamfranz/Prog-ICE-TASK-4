public class IncomingPhoneCall extends PhoneCall {

    public IncomingPhoneCall(String phoneNumber) {
        super(phoneNumber);
        setPrice(0.02); // 2 cents
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void displayInfo() {
        System.out.println("Incoming Call:");
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Rate: $0.02");
        System.out.println("Price: $" + price);
    }
}

