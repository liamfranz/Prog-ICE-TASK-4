public class OutgoingPhoneCall extends PhoneCall {
    private int minutes;

    public OutgoingPhoneCall(String phoneNumber, int minutes) {
        super(phoneNumber);
        this.minutes = minutes;
        setPrice(minutes * 0.04); // 4 cents per minute
    }

    @Override
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @Override
    public double getPrice() {
        return price;
    }

    @Override
    public void displayInfo() {
        System.out.println("Outgoing Call:");
        System.out.println("Phone Number: " + phoneNumber);
        System.out.println("Rate: $0.04 per minute");
        System.out.println("Minutes: " + minutes);
        System.out.println("Total Price: $" + price);
    }
}

