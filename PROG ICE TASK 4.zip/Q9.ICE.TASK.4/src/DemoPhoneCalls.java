import java.util.Scanner;

public class DemoPhoneCalls {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter phone number for incoming call: ");
        String incomingNumber = scanner.nextLine();
        IncomingPhoneCall incomingCall = new IncomingPhoneCall(incomingNumber);
        incomingCall.displayInfo();

        System.out.print("\nEnter phone number for outgoing call: ");
        String outgoingNumber = scanner.nextLine();
        System.out.print("Enter duration in minutes: ");
        int minutes = scanner.nextInt();
        OutgoingPhoneCall outgoingCall = new OutgoingPhoneCall(outgoingNumber, minutes);
        outgoingCall.displayInfo();

        scanner.close();
    }
}
