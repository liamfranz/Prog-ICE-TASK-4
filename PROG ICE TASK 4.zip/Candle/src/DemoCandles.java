import java.util.Scanner;

public class DemoCandles {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input for Candle
        System.out.print("Enter candle color: ");
        String candleColor = scanner.nextLine();
        System.out.print("Enter candle height (in inches): ");
        double candleHeight = scanner.nextDouble();

        Candle candle = new Candle(candleColor, candleHeight);
        System.out.println("Created Candle: " + candle);

        // Input for ScentedCandle
        scanner.nextLine(); // consume the newline
        System.out.print("Enter scented candle color: ");
        String scentedCandleColor = scanner.nextLine();
        System.out.print("Enter scented candle height (in inches): ");
        double scentedCandleHeight = scanner.nextDouble();
        scanner.nextLine(); // consume the newline

        System.out.println("Choose a scent for the scented candle:");
        System.out.println("1. Gardenia");
        System.out.println("2. Lavender");
        System.out.println("3. Vanilla");
        System.out.println("4. Citrus");
        System.out.print("Enter your choice (1-4): ");
        int scentChoice = scanner.nextInt();

        String scent = "";
        switch (scentChoice) {
            case 1: scent = "Gardenia"; break;
            case 2: scent = "Lavender"; break;
            case 3: scent = "Vanilla"; break;
            case 4: scent = "Citrus"; break;
            default: scent = "Unknown"; break;
        }

        ScentedCandle scentedCandle = new ScentedCandle(scentedCandleColor, scentedCandleHeight, scent);
        System.out.println("Created ScentedCandle: " + scentedCandle);

        scanner.close();
    }
}
