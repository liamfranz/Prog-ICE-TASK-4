public class Candle {
    private String color;
    private double height; // in inches
    private double price; // price determined by height

    public Candle(String color, double height) {
        this.color = color;
        setHeight(height); // setHeight will set the price
    }

    // Getter for color
    public String getColor() {
        return color;
    }

    // Setter for color
    public void setColor(String color) {
        this.color = color;
    }

    // Getter for height
    public double getHeight() {
        return height;
    }

    // Setter for height (updates price as well)
    public void setHeight(double height) {
        this.height = height;
        this.price = height * 2; // price is $2 per inch
    }

    // Getter for price
    public double getPrice() {
        return price;
    }

    @Override
    public String toString() {
        return "Candle [Color: " + color + ", Height: " + height + " inches, Price: $" + price + "]";
    }
}
