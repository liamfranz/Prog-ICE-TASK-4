public class ScentedCandle extends Candle {
    private String scent;

    public ScentedCandle(String color, double height, String scent) {
        super(color, height); // Call the parent constructor
        this.scent = scent;
        setHeight(height); // Call setHeight to set price
    }

    // Getter for scent
    public String getScent() {
        return scent;
    }

    // Setter for scent
    public void setScent(String scent) {
        this.scent = scent;
    }

    // Override setHeight to set price at $3 per inch
    @Override
    public void setHeight(double height) {
        super.setHeight(height);
        double price = height * 3; // price is $3 per inch for scented candles
        // Access the parent's price field through reflection if necessary, or adjust the design
        try {
            java.lang.reflect.Field priceField = Candle.class.getDeclaredField("price");
            priceField.setAccessible(true);
            priceField.set(this, price);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "ScentedCandle [Color: " + getColor() + ", Height: " + getHeight() + " inches, Price: $" + getPrice() +
                ", Scent: " + scent + "]";
    }
}

