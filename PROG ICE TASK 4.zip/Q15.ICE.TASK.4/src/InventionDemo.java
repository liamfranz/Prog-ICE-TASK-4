import java.time.LocalDate;
import java.util.Scanner;

public class InventionDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt for inventor information
        System.out.print("Enter the name of the inventor: ");
        String inventorName = scanner.nextLine();

        System.out.print("Enter the inventor's country of origin: ");
        String inventorCountry = scanner.nextLine();

        Inventor inventor = new Inventor(inventorName, inventorCountry);

        // Prompt for invention details
        System.out.print("Enter the description of the invention: ");
        String inventionDescription = scanner.nextLine();

        System.out.print("Enter the date of invention (YYYY-MM-DD): ");
        LocalDate inventionDate = LocalDate.parse(scanner.nextLine());

        // Create the Invention object
        Invention invention = new Invention(inventionDescription, inventor, inventionDate);

        // Display the information
        System.out.println(invention);

        scanner.close();
    }
}

