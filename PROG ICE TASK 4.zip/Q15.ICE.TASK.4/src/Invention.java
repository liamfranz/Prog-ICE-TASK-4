import java.time.LocalDate;

public class Invention {
    private String description;
    private Inventor inventor;
    private LocalDate dateOfInvention;

    public Invention(String description, Inventor inventor, LocalDate dateOfInvention) {
        this.description = description;
        this.inventor = inventor;
        this.dateOfInvention = dateOfInvention;
    }

    @Override
    public String toString() {
        return "Invention{" +
                "description='" + description + '\'' +
                ", inventor=" + inventor +
                ", dateOfInvention=" + dateOfInvention +
                '}';
    }
}

