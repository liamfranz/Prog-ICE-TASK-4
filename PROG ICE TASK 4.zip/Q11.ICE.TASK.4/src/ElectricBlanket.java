public class ElectricBlanket extends Blanket {
    private int heatSettings;
    private boolean hasAutoShutoff;

    // Default constructor
    public ElectricBlanket() {
        super();
        this.heatSettings = 1;
        this.hasAutoShutoff = false;
        updatePrice();
    }

    // Set method for heat settings
    public void setHeatSettings(int heatSettings) {
        if (heatSettings < 1 || heatSettings > 5) {
            this.heatSettings = 1; // Default value
        } else {
            this.heatSettings = heatSettings;
        }
        updatePrice();
    }

    // Set method for automatic shutoff
    public void setAutoShutoff(boolean hasAutoShutoff) {
        this.hasAutoShutoff = hasAutoShutoff;
        updatePrice();
    }

    private void updatePrice() {
        double basePrice = getPrice();
        double shutoffPrice = hasAutoShutoff ? 5.75 : 0;
        setPrice(basePrice + shutoffPrice);
    }

    // Get the current price
    private double getPrice() {
        return super.price; // Access parent class price
    }

    // Set the price in parent class
    private void setPrice(double price) {
        super.price = price;
    }

    @Override
    public String toString() {
        return super.toString() + ", ElectricBlanket{" +
                "heatSettings=" + heatSettings +
                ", hasAutoShutoff=" + hasAutoShutoff +
                '}';
    }
}
