import java.util.Scanner;

public class DemoBlankets {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Create and display a Blanket
        Blanket blanket = new Blanket();
        System.out.println("Initial Blanket: " + blanket);

        String materialInput;
        while (true) {
            System.out.print("Enter Blanket material (or 'exit' to quit): ");
            materialInput = scanner.nextLine();
            if (materialInput.equalsIgnoreCase("exit")) break;
            blanket.setMaterial(materialInput);
            System.out.println("Updated Blanket: " + blanket);

            System.out.print("Enter Blanket size: ");
            String sizeInput = scanner.nextLine();
            blanket.setSize(sizeInput);
            System.out.println("Updated Blanket: " + blanket);
        }

        // Create and display an ElectricBlanket
        ElectricBlanket electricBlanket = new ElectricBlanket();
        System.out.println("Initial Electric Blanket: " + electricBlanket);

        while (true) {
            System.out.print("Enter Electric Blanket material (or 'exit' to quit): ");
            materialInput = scanner.nextLine();
            if (materialInput.equalsIgnoreCase("exit")) break;
            electricBlanket.setMaterial(materialInput);
            System.out.println("Updated Electric Blanket: " + electricBlanket);

            System.out.print("Enter Electric Blanket size: ");
            sizeInput = scanner.nextLine();
            electricBlanket.setSize(sizeInput);
            System.out.println("Updated Electric Blanket: " + electricBlanket);

            System.out.print("Enter number of heat settings (1-5): ");
            int heatSettingsInput = Integer.parseInt(scanner.nextLine());
            electricBlanket.setHeatSettings(heatSettingsInput);

            System.out.print("Does it have automatic shutoff? (true/false): ");
            boolean shutoffInput = Boolean.parseBoolean(scanner.nextLine());
            electricBlanket.setAutoShutoff(shutoffInput);

            System.out.println("Final Electric Blanket: " + electricBlanket);
        }

        scanner.close();
    }
}
