public class Blanket {
    private String size;
    private String color;
    private String material;
    private double price;

    // Default constructor
    public Blanket() {
        this.size = "Twin";
        this.color = "White";
        this.material = "Cotton";
        this.price = 30.00;
    }

    // Set method for size
    public void setSize(String size) {
        switch (size.toLowerCase()) {
            case "twin":
                this.size = "Twin";
                price = 30.00; // Reset to base price
                break;
            case "double":
                this.size = "Double";
                price = 40.00; // $30 + $10
                break;
            case "queen":
                this.size = "Queen";
                price = 55.00; // $30 + $25
                break;
            case "king":
                this.size = "King";
                price = 70.00; // $30 + $40
                break;
            default:
                resetToDefaults();
                break;
        }
    }

    // Set method for color
    public void setColor(String color) {
        this.color = color;
    }

    // Set method for material
    public void setMaterial(String material) {
        switch (material.toLowerCase()) {
            case "cotton":
                this.material = "Cotton";
                price = getBasePrice(); // Reset to base price
                break;
            case "wool":
                this.material = "Wool";
                price += 20.00; // +$20
                break;
            case "cashmere":
                this.material = "Cashmere";
                price += 45.00; // +$45
                break;
            default:
                resetToDefaults();
                break;
        }
    }

    private double getBasePrice() {
        switch (size.toLowerCase()) {
            case "twin":
                return 30.00;
            case "double":
                return 40.00;
            case "queen":
                return 55.00;
            case "king":
                return 70.00;
            default:
                return 30.00;
        }
    }

    private void resetToDefaults() {
        this.size = "Twin";
        this.color = "White";
        this.material = "Cotton";
        this.price = 30.00;
    }

    @Override
    public String toString() {
        return "Blanket{" +
                "size='" + size + '\'' +
                ", color='" + color + '\'' +
                ", material='" + material + '\'' +
                ", price=$" + price +
                '}';
    }
}
