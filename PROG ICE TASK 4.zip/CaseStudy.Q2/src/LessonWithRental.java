// LessonWithRental.java
public class LessonWithRental extends Rental {
    // Boolean field to indicate if a lesson is required
    private boolean lessonRequired;

    // Array of instructor names for different equipment types
    public static final String[] INSTRUCTORS = {
            "John Doe",     // Personal Watercraft
            "Jane Smith",   // Pontoon Boat
            "Sam Brown",    // Kayak
            "Emily White",  // Canoe
            "Robert Green", // Jet Ski
            "Sara Black",   // Paddleboard
            "Michael Blue", // Sailboat
            "Olivia Gray"   // Windsurfing
    };

    // Equipment type associated with the rental
    private int equipmentType;

    // Constructor for LessonWithRental
    public LessonWithRental(int contractNumber, int rentalMinutes, int equipmentType) {
        super(contractNumber, rentalMinutes); // Call Rental constructor
        this.equipmentType = equipmentType;

        // Set lessonRequired to true for personal watercraft and pontoon boat
        if (equipmentType == 0 || equipmentType == 1) {
            this.lessonRequired = true;
        } else {
            this.lessonRequired = false;
        }
    }

    // Method to return the instructor and lesson details
    public String getInstructor() {
        String equipmentName = getEquipmentName(equipmentType);
        String lessonMessage = lessonRequired ? "Lesson is required." : "Lesson is optional.";
        String instructor = INSTRUCTORS[equipmentType];

        return "Equipment: " + equipmentName + "\n" +
                lessonMessage + "\n" +
                "Instructor: " + instructor;
    }

    // Helper method to get the equipment name based on the equipment type
    private String getEquipmentName(int equipmentType) {
        switch (equipmentType) {
            case 0: return "Personal Watercraft";
            case 1: return "Pontoon Boat";
            case 2: return "Kayak";
            case 3: return "Canoe";
            case 4: return "Jet Ski";
            case 5: return "Paddleboard";
            case 6: return "Sailboat";
            case 7: return "Windsurfing";
            default: return "Unknown Equipment";
        }
    }

    // Overriding the toString() method to display rental details
    @Override
    public String toString() {
        return super.toString() + "\n" + getInstructor();
    }
}
