// LessonWithRentalDemo.java
import java.util.Scanner;

public class LessonWithRentalDemo {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LessonWithRental[] rentals = new LessonWithRental[4];  // Array to store 4 LessonWithRental objects

        // Collect user input for each LessonWithRental
        for (int i = 0; i < rentals.length; i++) {
            System.out.println("Enter details for LessonWithRental " + (i + 1));

            System.out.print("Contract Number: ");
            int contractNumber = scanner.nextInt();

            System.out.print("Rental Minutes: ");
            int rentalMinutes = scanner.nextInt();

            System.out.println("Equipment Types:");
            System.out.println("0. Personal Watercraft");
            System.out.println("1. Pontoon Boat");
            System.out.println("2. Kayak");
            System.out.println("3. Canoe");
            System.out.println("4. Jet Ski");
            System.out.println("5. Paddleboard");
            System.out.println("6. Sailboat");
            System.out.println("7. Windsurfing");
            System.out.print("Choose Equipment Type (0-7): ");
            int equipmentType = scanner.nextInt();

            // Create a new LessonWithRental object and store it in the array
            rentals[i] = new LessonWithRental(contractNumber, rentalMinutes, equipmentType);
            System.out.println(); // Print a blank line for separation
        }

        // Menu for sorting options
        while (true) {
            System.out.println("Choose a sorting option:");
            System.out.println("1. Sort by Contract Number");
            System.out.println("2. Sort by Equipment Type");
            System.out.println("3. Sort by Price (ascending)");
            System.out.println("4. Exit");

            int choice = scanner.nextInt();
            switch (choice) {
                case 1:
                    // Sort by Contract Number
                    sortByContractNumber(rentals);
                    break;
                case 2:
                    // Sort by Equipment Type
                    sortByEquipmentType(rentals);
                    break;
                case 3:
                    // Sort by Price (assuming we have price information in the Rental class)
                    sortByPrice(rentals);
                    break;
                case 4:
                    System.out.println("Exiting program.");
                    return;
                default:
                    System.out.println("Invalid choice. Try again.");
            }

            // Print the sorted list of rentals
            printRentals(rentals);
        }
    }

    // Method to print all rentals
    private static void printRentals(LessonWithRental[] rentals) {
        for (LessonWithRental rental : rentals) {
            System.out.println(rental);  // Calls the overridden toString() method
            System.out.println("----------------------------");
        }
    }

    // Sort rentals by contract number
    private static void sortByContractNumber(LessonWithRental[] rentals) {
        for (int i = 0; i < rentals.length - 1; i++) {
            for (int j = i + 1; j < rentals.length; j++) {
                if (rentals[i].getContractNumber() > rentals[j].getContractNumber()) {
                    LessonWithRental temp = rentals[i];
                    rentals[i] = rentals[j];
                    rentals[j] = temp;
                }
            }
        }
    }

    // Sort rentals by equipment type
    private static void sortByEquipmentType(LessonWithRental[] rentals) {
        for (int i = 0; i < rentals.length - 1; i++) {
            for (int j = i + 1; j < rentals.length; j++) {
                if (rentals[i].getEquipmentType() > rentals[j].getEquipmentType()) {
                    LessonWithRental temp = rentals[i];
                    rentals[i] = rentals[j];
                    rentals[j] = temp;
                }
            }
        }
    }

    // Sort rentals by price (assuming a price field exists in Rental class)
    private static void sortByPrice(LessonWithRental[] rentals) {
        for (int i = 0; i < rentals.length - 1; i++) {
            for (int j = i + 1; j < rentals.length; j++) {
                if (rentals[i].getPrice() > rentals[j].getPrice()) {
                    LessonWithRental temp = rentals[i];
                    rentals[i] = rentals[j];
                    rentals[j] = temp;
                }
            }
        }
    }
}
