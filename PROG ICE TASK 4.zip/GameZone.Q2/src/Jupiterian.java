// Jupiterian.java
public class Jupiterian extends Alien {

    // Constructor that initializes the Jupiterian's attributes
    public Jupiterian() {
        super(2, 4, "purple");  // Jupiterians have 2 eyes, 4 limbs, and are purple
    }

    // Override the toString method to provide Jupiterian's description
    @Override
    public String toString() {
        return "Jupiterian [Eyes: " + numberOfEyes + ", Limbs: " + numberOfLimbs + ", Color: " + color + "]";
    }
}

