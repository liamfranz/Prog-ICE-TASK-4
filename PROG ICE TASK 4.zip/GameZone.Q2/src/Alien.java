// Alien.java
public abstract class Alien {
    // Protected data members (attributes of the Alien)
    protected int numberOfEyes;
    protected int numberOfLimbs;
    protected String color;

    // Constructor to initialize the alien's attributes
    public Alien(int numberOfEyes, int numberOfLimbs, String color) {
        this.numberOfEyes = numberOfEyes;
        this.numberOfLimbs = numberOfLimbs;
        this.color = color;
    }

    // Abstract toString method that will be overridden by subclasses
    public abstract String toString();
}
