// Martian.java
public class Martian extends Alien {

    // Constructor that initializes the Martian's attributes
    public Martian() {
        super(4, 6, "green");  // Martians have 4 eyes, 6 limbs, and are green
    }

    // Override the toString method to provide Martian's description
    @Override
    public String toString() {
        return "Martian [Eyes: " + numberOfEyes + ", Limbs: " + numberOfLimbs + ", Color: " + color + "]";
    }
}
