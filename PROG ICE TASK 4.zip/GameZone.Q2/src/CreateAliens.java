// CreateAliens.java
public class CreateAliens {
    public static void main(String[] args) {
        // Instantiate a Martian and a Jupiterian
        Alien martian = new Martian();
        Alien jupiterian = new Jupiterian();

        // Display the descriptions using the toString() method
        System.out.println(martian.toString());
        System.out.println(jupiterian.toString());
    }
}
