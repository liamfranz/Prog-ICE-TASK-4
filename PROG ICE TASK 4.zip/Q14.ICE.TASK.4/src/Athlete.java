public class Athlete implements Runner {
    @Override
    public void run() {
        System.out.println("The athlete runs to compete and achieve personal bests.");
    }
}

