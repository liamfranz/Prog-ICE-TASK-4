import java.util.Scanner;

public class DemoRunners {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter the type of runner (Machine, Athlete, PoliticalCandidate): ");
        String input = scanner.nextLine();

        Runner runner = null;

        switch (input.toLowerCase()) {
            case "machine":
                runner = new Machine();
                break;
            case "athlete":
                runner = new Athlete();
                break;
            case "politicalcandidate":
                runner = new PoliticalCandidate();
                break;
            default:
                System.out.println("Unknown runner type.");
                break;
        }

        if (runner != null) {
            runner.run();
        }

        scanner.close();
    }
}

