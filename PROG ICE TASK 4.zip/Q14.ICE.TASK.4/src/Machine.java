public class Machine implements Runner {
    @Override
    public void run() {
        System.out.println("The machine runs operations efficiently.");
    }
}
