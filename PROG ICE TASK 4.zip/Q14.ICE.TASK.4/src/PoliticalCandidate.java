public class PoliticalCandidate implements Runner {
    @Override
    public void run() {
        System.out.println("The political candidate runs for office to gain support and votes.");
    }
}

